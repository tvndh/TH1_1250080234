-- D?ng n�y �? tr�nh l?i khi t?o user tr�n b?n m?i
ALTER SESSION SET "_ORACLE_SCRIPT"=true;

-- T?o user t�n l� nguyenduonghothachvu, m?t kh?u l� 123456
CREATE USER nguyenduonghothachvu IDENTIFIED BY 123456;

-- C?p to�n quy?n cho user n�y
GRANT CONNECT, RESOURCE, DBA TO nguyenduonghothachvu;